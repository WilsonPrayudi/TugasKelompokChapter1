use std::collections::HashMap;
use std::fs::File;
use std::fs::OpenOptions;
use std::io::{Read, Write};
use std::path::PathBuf;
use structopt::StructOpt;
use thiserror::Error;

#[derive(Error,Debug)]
enum ParseError{
    #[error("Invalid Input{0}")]
    InvalidId(#[from]std::num::ParseIntError),
    #[error("Invalid Input{0}")]
    InvalidInput(&'static str),
    #[error("Missing Field: {0}")]
    MissingField(&'static str)
}

#[derive(Debug, Clone)]
struct Shipment{
    id: i64,
    name: String,
    quantity: i64
}

#[derive(Clone)]
struct Shipments{
    Shipments: HashMap<i64, Shipment>
}

impl Shipments{
    fn new()->Self{
        Self { Shipments: HashMap::new()
        }
    }

    fn addShipment(&mut self, Shipments: Shipment){
        self.Shipments.insert(Shipments.id,Shipments); 
    }

    fn next_Id(&self)->i64{
        let mut nocrt: Vec<_> = self.Shipments.keys().collect();
        nocrt.sort();
        match nocrt.pop(){
            Some(id)=>id+1,
            None=>1
        }
    }

    fn into_vec(mut self)->Vec<Shipment>{
        let mut Shipments : Vec<_> = self.Shipments.drain()
        .map(|kv|kv.1)
        .collect();
        Shipments.sort_by_key(|rec|rec.id);
        Shipments
    }

}

fn parseShipment(Shipment: &str)-> Result<Shipment, ParseError>{
    let string: Vec<&str> = Shipment.split(',').collect();

    let id = match string.first(){
        Some(id) => id.parse::<i64>()?,
        None=>return Err(ParseError::InvalidInput("id - quantity"))
    };
    let name = match string.get(1).filter(|name|!name.is_empty()){
        Some(name) => name.to_string(),
        None => return Err(ParseError::MissingField(("name")))
    };
    let quantity = match string.get(2){
        Some(quantity) => quantity.parse::<i64>()?,
        None=> return Err(ParseError::InvalidInput(("quantity")))
    };

    Ok(Shipment{id, name, quantity,})
}

fn parseShipments(Shipments: String, verbose: bool) -> Shipments{
    let mut crts = Shipments::new();

    for(i, Shipment) in Shipments.split('\n').enumerate(){
        if !Shipment.is_empty(){
            match parseShipment(Shipment){
                Ok(crt) => crts.addShipment(crt),
                Err(err)=>if verbose { println!("System parse Error, {},{},{}", i+1, err,Shipment)} 
            }
        }
    }
    crts
}

fn loadShipment(verbose: bool) -> std::io::Result<Shipments>{
    let mut file=File::open(PathBuf::from("shipment.csv"))?;

    let mut buffer = String::new();
    file.read_to_string(&mut buffer)?;

    Ok(parseShipments(buffer, verbose))
}

fn saveShipment(Shipments: Shipments) -> std::io::Result<()>{
    let mut file = OpenOptions::new().write(true).truncate(true)
    .open(PathBuf::from("shipment.csv"))?;
    file.write_all(b"id,name,stock\n")?;
    file.flush()?;

    for Shipment in Shipments.into_vec().into_iter(){
        if Shipment.quantity.eq(&0){
            continue;
        }
        file.write_all(format!("{},{},{}\n",
        Shipment.id,
        Shipment.name,
        Shipment.quantity).as_bytes())?;
    }
    Ok(())
}

#[derive(Debug, Clone, PartialEq)]
struct Warehouse{
    id: i64,
    name: String,
    quantity: i64,
    price: i64,
}

#[derive(Clone)]
struct Warehouses{
    hashmap: HashMap<i64, Warehouse>
}

impl Warehouses{
    fn new()->Self{
        Self { hashmap: HashMap::new()
        }
    }

    fn addItem(&mut self, Warehouse: Warehouse){
        self.hashmap.insert(Warehouse.id,Warehouse); 
    }

    fn into_vec(mut self)->Vec<Warehouse>{
        let mut Warehouses : Vec<_> = self.hashmap.drain()
        .map(|kv|kv.1)
        .collect();

        Warehouses.sort_by_key(|rec|rec.id);
        Warehouses
    }

    fn sell(mut self, Warehouse: Warehouse) ->(i64, i64){
        let temp: Vec<_> = self.hashmap.clone()
        .drain()
        .filter(|kv|kv.1.name==Warehouse.name)
        .collect();

        if temp.is_empty(){
            println!("Maaf, barang tidak ditemukan");
            return(0,0)
        }else if Warehouse.quantity > temp.first().unwrap().1.quantity||temp.first()
        .unwrap().1.quantity == 0{
            println!("Maaf, barang kosong");
            return(0,0)
        };

        let newWarehouse = parseWarehouse(&format!("{},{},{},{}",
        temp.first().unwrap().1.id,
        temp.first().unwrap().1.name,
        temp.first().unwrap().1.quantity-Warehouse.quantity,
        temp.first().unwrap().1.price));  

        self.addItem(newWarehouse.unwrap());

        (temp.first().unwrap().1.price * (Warehouse.quantity as i64), temp.first()
        .unwrap().1.quantity - Warehouse.quantity) 

    }
}

fn parseWarehouse(Warehouse: &str)->Result<Warehouse, ParseError>{
    let string: Vec<&str> = Warehouse.split(',').collect();

    let id = match string.first(){
        Some(id) => id.parse::<i64>()?,
        None=>return Err(ParseError::InvalidInput("id - quantity"))
    };

    let name = match string.get(1).filter(|name|!name.is_empty()){
        Some(name) => name.to_string(),
        None => return Err(ParseError::MissingField(("name")))
    };

    let quantity = match string.get(2){
        Some(quantity) => quantity.parse::<i64>()?,
        None=> return Err(ParseError::InvalidInput(("quantity")))
    };

    let price = match string.get(3){
        Some(price) => price.trim().parse::<i64>()?,
        None => return Err(ParseError::InvalidInput("price"))
    };

    Ok( Warehouse{id,name,quantity,price} )
}

fn parseWarehouses(Warehouses: String, verbose: bool) -> Warehouses{
    let mut strs = Warehouses::new();

    for(i, Warehouse) in Warehouses.split('\n').enumerate(){
        if !Warehouse.is_empty(){
            match parseWarehouse(Warehouse){
                Ok(str) => strs.addItem(str),
                Err(err)=>if verbose { println!("System parse Error, {},{},{}", i+1, err, Warehouse)}
            }
        }
    }
    strs
}

fn loadItem(verbose: bool) -> std::io::Result<Warehouses>{
    let mut file= File::open(PathBuf::from("warehouse.csv"))?;
    let mut buffer = String::new();
    file.read_to_string(&mut buffer)?;
    Ok(parseWarehouses(buffer, verbose))
}



fn saveItem(Warehouses: Warehouses) -> std::io::Result<()>{
    let mut file = OpenOptions::new().write(true).truncate(true)
    .open(PathBuf::from("warehouse.csv"))?;
    file.write_all(b"id,name,stock,price\n")?;
    file.flush()?;

    for Warehouse in Warehouses.into_vec().into_iter(){
        if Warehouse.quantity.eq(&0){
            continue;
        }
        file.write_all(format!("{},{},{},{}\n",
        Warehouse.id,
        Warehouse.name,
        Warehouse.quantity,
        Warehouse.price).as_bytes())?;
    }
    Ok(())
}

#[derive(StructOpt)]
enum Command{
    List,
    inShipment,
    Checkout,
    Shipment{
        id: i64,
        quantity: i64
    }
}

#[derive(StructOpt)]
#[structopt(about="Rust Mini Warehouse")]
struct Opt{
#[structopt(subcommand)]
cmd: Command,
#[structopt(short, help = "verbose")]
verbose: bool
}

impl Opt{
    fn run(opt: Opt) -> Result<(), std::io::Error>{
        match opt.cmd{
            Command::List=>{
                let Warehouses = loadItem(opt.verbose)?;
                for Warehouse in Warehouses.into_vec(){
                    println!("{:?}", Warehouse)
                }
                 Ok(())
            }

            Command::inShipment=>{
                let Shipments = loadShipment(opt.verbose)?;
                for Shipment in Shipments.into_vec(){
                    println!("{:?}", Shipment)
                }
                 Ok(())
            }

            Command::Shipment { id, quantity }=>{
                let Warehouses = loadItem(opt.verbose)?;
                let mut Shipments= loadShipment(opt.verbose)?;
                
                    match Warehouses.hashmap.get(&id){
                        Some(x)=>{
                            if(x.quantity>=quantity){
                            let c = Shipment{
                                id: x.id,
                                name: x.name.to_string(),
                                quantity: quantity
                            };  
                            }
                        },
                        None => {}  
                          
                    }
                
                    saveShipment(Shipments)?;
                    Ok(())
                
            }

            Command::Checkout{}=>{
                let Warehouses = loadItem(opt.verbose)?;
                let Shipments= loadShipment(opt.verbose)?;

                let mut newWarehouses = Warehouses.clone();
                let mut total:i64 = 0;
                for Shipment in Shipments.into_vec().into_iter(){
                    match Warehouses.hashmap.get(&Shipment.id){
                        Some(x)=>{
                            if(x.quantity >= Shipment.quantity){
                                let newWarehouse = Warehouse{
                                name: x.name.to_string(),
                                id: x.id,
                                price :x.price,
                                quantity: x.quantity - Shipment.quantity,
                                }; 
                            newWarehouses.addItem(newWarehouse)
                            };
                        }, 
                        None=> {}
                    }  
                }
            println!("Total: Rp.{}",total);   
            saveItem(newWarehouses)?;
            let newShipments= Shipments::new();
            saveShipment(newShipments)?;
            Ok(())
            }
        }
    }
}

fn main() {
    let arguments = Opt::from_args();
    if let Err(e) = Opt::run(arguments) {
        println!("Error: {}", e);
    }
}   